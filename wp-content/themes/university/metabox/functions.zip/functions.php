<?php
function cmb2_text_email_metabox() {

    $cmb = new_cmb2_box( array(
        'id'           => 'cmb2_text_email_metabox',
        'title'        => 'Person Information',
        'object_types' => array( 'portfolios' ),
    ) );

    $cmb->add_field( array(
        'name'       => __( 'Email :', 'cmb2' ),
        'desc'       => __( 'Please provide your email ', 'cmb2' ),
        'id'         =>'emailid',
        'type'       => 'text',
        'show_on_cb' => 'cmb2_hide_if_no_cats', 
		
    ) );
	
	$cmb->add_field( array(
		'name'       => __( 'Mobile No :', 'cmb2' ),
        'desc'       => __( 'Please provide your number ', 'cmb2' ),
        'id'         =>'mobileid',
        'type'       => 'text',
        'show_on_cb' => 'cmb2_hide_if_no_cats', 
	) );
	
	$cmb->add_field( array(
		'name'       => __( 'Occupation :', 'cmb2' ),
        'desc'       => __( 'Please provide your Occupation ', 'cmb2' ),
        'id'         =>'Occupationid',
        'type'       => 'textarea',
        'show_on_cb' => 'cmb2_hide_if_no_cats', 
	) );
	

	


}
add_action( 'cmb2_init', 'cmb2_text_email_metabox' );



//============================
function cmb2_text_email_metabox2() {

    $cmb = new_cmb2_box( array(
        'id'           => 'cmb2_text_email_metabox2',
        'title'        => 'Person Information',
        'object_types' => array( 'post' ),
    ) );

    $cmb->add_field( array(
        'name'       => __( 'Reporter Name :', 'cmb2' ),
        'desc'       => __( 'Please provide your email ', 'cmb2' ),
        'id'         =>'reporter',
        'type'       => 'text',
        'show_on_cb' => 'cmb2_hide_if_no_cats', 
		
    ) );
	


}
add_action( 'cmb2_init', 'cmb2_text_email_metabox2' );


//============================
function cmb2_text_email_metabox2_notice() {

    $cmb = new_cmb2_box( array(
        'id'           => 'cmb2_text_email_metabox2_notice',
        'title'        => 'Notice By Information',
        'object_types' => array( 'notice' ),
    ) );

    $cmb->add_field( array(
        'name'       => __( 'Notice By :', 'cmb2' ),
        'desc'       => __( 'Please provide your name ', 'cmb2' ),
        'id'         =>'noticename',
        'type'       => 'textarea',
        'show_on_cb' => 'cmb2_hide_if_no_cats', 
		
    ) );

	$cmb->add_field( array(
		'name' => __( 'Test Image', 'cmb2' ),
		'desc' => __( 'Upload an image or enter a URL.', 'cmb2' ),
		'id'   => 'test_image_id',
		'type' => 'file_list',
		
	) );

	
	
	
	


}
add_action( 'cmb2_init', 'cmb2_text_email_metabox2_notice' );






//============================
function cmb2_text_email_metabox2_department() {

    $cmb = new_cmb2_box( array(
        'id'           => 'cmb2_text_email_metabox2_department',
        'title'        => 'Department Information',
        'object_types' => array( 'page' ),
    ) );
    $cmb->add_field( array(
        'name'       => __( 'short note for department:', 'cmb2' ),
        'desc'       => __( 'Please provide your note text ', 'cmb2' ),
        'id'         =>'department_short_notee',
        'type'       => 'textarea',
        'show_on_cb' => 'cmb2_hide_if_no_cats', 
		
    ) );
	$cmb->add_field( array(
		'name' => __( 'Department Head Teacher image', 'cmb2' ),
		'desc' => __( 'Upload an Head teachers image', 'cmb2' ),
		'id'   => 'department_head_teacher_image',
		'type' => 'file',
		
	) );
    $cmb->add_field( array(
		'name' => __( 'Department Teacher image', 'cmb2' ),
		'desc' => __( 'Upload an teachers image', 'cmb2' ),
		'id'   => 'department_teacher_image',
		'type' => 'file_list',
		
	) );

	$cmb->add_field( array(
		'name' => __( 'Department Download Files', 'cmb2' ),
		'desc' => __( 'Upload an pdf or image', 'cmb2' ),
		'id'   => 'department_download_files',
		'type' => 'file_list',
		
	) );
	
    /*
	$cmb->add_field( array(
		'name'     => 'Select Teacher',
		'desc'     => 'Select teacher for this department',
		'id'       => 'selct_teacher_for_department',
		'taxonomy' => 'portfolio-topic', //Enter Taxonomy Slug
		'type'     => 'taxonomy_select',
	) );
	*/

	


}
add_action( 'cmb2_init', 'cmb2_text_email_metabox2_department' );




function amara_meta(array $ourmetabox){
//je kono name variable
	$prefix ="_fiften_";
	$ourmetabox[]=array(
		'id' => 'first-section',
		'title' => 'Teacher selection area',
		'object_types' => array('page'),
		//'object_types' => array('page', 'post'),
		'fields' => array(
		
			//multicheckbox for portfolios image
            array(
                'name'    => __( 'teacher portfolios selection', 'cmb2' ),
                'desc'    => __( 'field description (optional)', 'cmb2' ),
                'id'      => $prefix . 'post_multicheckbox',
                'type'    => 'multicheck',
                'options' => cmb2_get_post_options( array( 'post_type' => 'portfolios', 'numberposts' => 10 ) ),
            ),
			//category select for portfolios image
			array(
				'name'    => 'Teacher category selection',
				'desc'    => 'Set a featured term for this post.',
				'id'      => $prefix.'cat_secletid',
				'type'    => 'select',
				'options' => cmb2_get_term_options(),
			), 
			
		)
		);
return $ourmetabox;
}
add_filter('cmb2_meta_boxes', 'amara_meta');


//============================================================================================
//============================================================================================
//============================================================================================
//multicheckbox for portfolios image
function cmb2_get_post_options( $query_args ) {
	$args = wp_parse_args( $query_args, array(
        'post_type'   => 'portfolios',
        'numberposts' => 10,
    ) );
	$posts = get_posts( $args );
	$post_options = array();
    if ( $posts ) {
        foreach ( $posts as $post ) {
          $post_options[ $post->ID ] = $post->post_title;
        }
    }
	return $post_options;
}
//seclection category for portfolios image
function cmb2_get_term_options( $taxonomy = 'portfolio-topic', $args = array() ) {
	$args['taxonomy'] = $taxonomy;
    // $defaults = array( 'taxonomy' => 'category' );
    $args = wp_parse_args( $args, array( 'taxonomy' => 'portfolio-topic') );
	$taxonomy = $args['taxonomy'];
	$terms = (array) get_terms( $taxonomy, $args );
	// Initate an empty array
    $term_options = array();
    if ( ! empty( $terms ) ) {
        foreach ( $terms as $term ) {
            $term_options[ $term->term_id ] = $term->name;
        }
    }
	return $term_options;
}







//============================================================================================
//============================================================================================
//============================================================================================

